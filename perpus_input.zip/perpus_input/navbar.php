
<nav class="navbar navbar-expand-lg navbar navbar-dark bg-dark">
  <a class="navbar-brand" href="index.php"><b>DATA BUKU PERPUSTAKAAN<b></a>
  <div class="collapse navbar-collapse">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item">
        <a class="nav-link" href="./index.php?target=input">INPUT BUKU</a>
      </li>
    </ul>
  </div>
</nav>
